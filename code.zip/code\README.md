# Multi-Modal Evidence Review Agent

This solution reads the provided CSV files and local images, reviews each claim, and writes an `output.csv` with the exact schema from `problem_statement.md`.

## Approach

- Parse the conversation to identify the claimed damage, object part, and issue family.
- Look up `user_history.csv` and add `user_history_risk` / `manual_review_required` as contextual risk flags.
- Use an optional structured vision model call, enabled by `OPENAI_API_KEY`, to inspect every submitted image and decide support, contradiction, or insufficient evidence.
- Sanitize every model response to the allowed values and exact output column order.
- Fall back conservatively when no VLM is configured: the fallback extracts text/history signals but returns `not_enough_information` because images are required for a real visual decision.

## Run Predictions

From the repository root:

```bash
python code/main.py --dataset-root dataset --input claims.csv --output output.csv
```

To force the deterministic fallback:

```bash
python code/main.py --dataset-root dataset --input claims.csv --output output.csv --no-vlm
```

The default VLM model is `gpt-4.1-mini`. Override it with:

```bash
VLM_MODEL=gpt-4.1 python code/main.py --dataset-root dataset --input claims.csv --output output.csv
```

## Evaluate

```bash
python code/evaluation/main.py --repo-root .
```

This creates:

- `code/evaluation/sample_predictions.csv`
- `code/evaluation/evaluation_report.md`

## Notes

No API keys or secrets are stored in the repository. The model call is one claim per request and includes all images for that row so multi-image evidence can be evaluated together.
