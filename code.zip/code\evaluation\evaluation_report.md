# Evaluation Report

## Sample Metrics

Rows evaluated: 20
Images processed: 29

- evidence_standard_met: 0.100
- risk_flags: 0.550
- issue_type: 0.400
- object_part: 0.600
- claim_status: 0.100
- supporting_image_ids: 0.100
- valid_image: 0.100
- severity: 0.100
- row_exact_match: 0.000

## Strategies Compared

1. Deterministic text/history fallback: extracts likely issue and part from the conversation, adds user-history risk, and refuses to decide visual support without image review.
2. Final VLM strategy: sends each claim, the relevant history, evidence requirements, and all images to a structured vision prompt, then validates values against the allowed schema.

The final strategy is the VLM reviewer with deterministic schema sanitation. The fallback is included so the code remains runnable in environments without API credentials, but it is intentionally conservative because images are the primary source of truth.

## Operational Analysis

- Sample processing: 20 model calls and 29 images when the VLM path is enabled.
- Test processing: 44 model calls and 82 images when the VLM path is enabled.
- Approximate prompt tokens: 1.0k-1.4k text tokens per claim plus image tokens determined by the selected vision model and image detail.
- Approximate output tokens: 120-220 per claim.
- Pricing assumption: with a low-cost multimodal model such as `gpt-4.1-mini`, budget roughly a few cents for this dataset; exact cost depends on image tokenization and current provider pricing.
- Latency: one request per row, typically 1-5 seconds per row depending on model load and image size; the provided runner is sequential for simplicity.
- TPM/RPM: for larger runs, batch with a small worker pool, cache image-analysis outputs by file hash, and retry transient failures with exponential backoff.
- Caching: image bytes are read once per claim in this implementation; a production variant should store per-image observations and combine them with claim-specific reasoning.
