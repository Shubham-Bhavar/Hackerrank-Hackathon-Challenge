from __future__ import annotations

import argparse
import base64
import csv
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any


OUTPUT_COLUMNS = [
    "user_id",
    "image_paths",
    "user_claim",
    "claim_object",
    "evidence_standard_met",
    "evidence_standard_met_reason",
    "risk_flags",
    "issue_type",
    "object_part",
    "claim_status",
    "claim_status_justification",
    "supporting_image_ids",
    "valid_image",
    "severity",
]

ISSUE_TYPES = {
    "dent",
    "scratch",
    "crack",
    "glass_shatter",
    "broken_part",
    "missing_part",
    "torn_packaging",
    "crushed_packaging",
    "water_damage",
    "stain",
    "none",
    "unknown",
}
CLAIM_STATUSES = {"supported", "contradicted", "not_enough_information"}
SEVERITIES = {"none", "low", "medium", "high", "unknown"}
RISK_FLAGS = {
    "none",
    "blurry_image",
    "cropped_or_obstructed",
    "low_light_or_glare",
    "wrong_angle",
    "wrong_object",
    "wrong_object_part",
    "damage_not_visible",
    "claim_mismatch",
    "possible_manipulation",
    "non_original_image",
    "text_instruction_present",
    "user_history_risk",
    "manual_review_required",
}
OBJECT_PARTS = {
    "car": {
        "front_bumper",
        "rear_bumper",
        "door",
        "hood",
        "windshield",
        "side_mirror",
        "headlight",
        "taillight",
        "fender",
        "quarter_panel",
        "body",
        "unknown",
    },
    "laptop": {
        "screen",
        "keyboard",
        "trackpad",
        "hinge",
        "lid",
        "corner",
        "port",
        "base",
        "body",
        "unknown",
    },
    "package": {
        "box",
        "package_corner",
        "package_side",
        "seal",
        "label",
        "contents",
        "item",
        "unknown",
    },
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=OUTPUT_COLUMNS, quoting=csv.QUOTE_MINIMAL)
        writer.writeheader()
        for row in rows:
            writer.writerow({col: row.get(col, "") for col in OUTPUT_COLUMNS})


def load_lookup(path: Path, key: str) -> dict[str, dict[str, str]]:
    if not path.exists():
        return {}
    return {row[key]: row for row in read_csv(path)}


def image_id(image_path: str) -> str:
    return Path(image_path).stem


def encode_image(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode("ascii")


def parse_claim_text(text: str, claim_object: str) -> tuple[str, str]:
    t = text.lower()
    issue = "unknown"
    if any(w in t for w in ["shatter", "shattered"]):
        issue = "glass_shatter"
    elif any(w in t for w in ["crack", "cracked"]):
        issue = "crack"
    elif any(w in t for w in ["dent", "dented"]):
        issue = "dent"
    elif any(w in t for w in ["scratch", "scrape", "scratched"]):
        issue = "scratch"
    elif any(w in t for w in ["missing", "not inside", "faltan"]):
        issue = "missing_part"
    elif any(w in t for w in ["broken", "broke", "damaged", "not sitting"]):
        issue = "broken_part"
    elif any(w in t for w in ["torn", "open", "seal"]):
        issue = "torn_packaging"
    elif any(w in t for w in ["crushed", "dab gaya", "crush"]):
        issue = "crushed_packaging"
    elif any(w in t for w in ["water", "wet", "liquid"]):
        issue = "water_damage"
    elif any(w in t for w in ["stain", "oil"]):
        issue = "stain"

    part_patterns = {
        "front_bumper": ["front bumper", "parachoques delantero"],
        "rear_bumper": ["rear bumper", "back bumper", "parachoques trasero"],
        "door": [" door", "door panel"],
        "hood": ["hood", "bonnet"],
        "windshield": ["windshield", "front glass"],
        "side_mirror": ["side mirror", "left mirror", "right mirror", "mirror"],
        "headlight": ["headlight"],
        "taillight": ["taillight", "back light"],
        "fender": ["fender"],
        "quarter_panel": ["quarter panel"],
        "screen": ["screen", "display", "pantalla"],
        "keyboard": ["keyboard", "keycap", "keys", "teclas"],
        "trackpad": ["trackpad", "touchpad"],
        "hinge": ["hinge"],
        "lid": ["lid", "outer lid"],
        "corner": ["corner"],
        "port": ["port"],
        "base": ["base"],
        "package_corner": ["box corner", "package corner", "corner"],
        "package_side": ["side", "surface"],
        "seal": ["seal"],
        "label": ["label", "shipping label"],
        "contents": ["contents", "inside", "not inside"],
        "item": ["item", "product"],
        "box": ["box", "package", "parcel"],
        "body": ["body", "panel"],
    }
    allowed = OBJECT_PARTS[claim_object]
    part = "unknown"
    for candidate, patterns in part_patterns.items():
        if candidate in allowed and any(p in t for p in patterns):
            part = candidate
            break
    return issue, part


def base_prediction(row: dict[str, str], history: dict[str, str]) -> dict[str, str]:
    issue, part = parse_claim_text(row["user_claim"], row["claim_object"])
    flags: list[str] = []
    for flag in str(history.get("history_flags", "none")).split(";"):
        flag = flag.strip()
        if flag and flag != "none" and flag in RISK_FLAGS:
            flags.append(flag)
    if not flags:
        flags = ["none"]
    return {
        **{k: row[k] for k in ["user_id", "image_paths", "user_claim", "claim_object"]},
        "evidence_standard_met": "false",
        "evidence_standard_met_reason": "No configured vision model reviewed the images, so visual sufficiency cannot be confirmed.",
        "risk_flags": ";".join(dict.fromkeys(flags)),
        "issue_type": issue,
        "object_part": part,
        "claim_status": "not_enough_information",
        "claim_status_justification": "A vision review is required because images are the primary evidence for this claim.",
        "supporting_image_ids": "none",
        "valid_image": "false",
        "severity": "unknown",
    }


def openai_review(
    row: dict[str, str],
    history: dict[str, str],
    requirements: list[dict[str, str]],
    dataset_root: Path,
    model: str,
) -> dict[str, Any]:
    from openai import OpenAI

    client = OpenAI()
    image_paths = [p.strip() for p in row["image_paths"].split(";") if p.strip()]
    image_blocks = []
    for p in image_paths:
        full = dataset_root / p
        image_blocks.append(
            {
                "type": "input_image",
                "image_url": f"data:image/jpeg;base64,{encode_image(full)}",
                "detail": "high",
            }
        )

    relevant_requirements = [
        r
        for r in requirements
        if r.get("claim_object") in {"all", row["claim_object"]}
    ]
    prompt = {
        "task": "Verify a damage claim using images as primary evidence.",
        "input_row": row,
        "image_ids": [image_id(p) for p in image_paths],
        "user_history": history,
        "evidence_requirements": relevant_requirements,
        "instructions": [
            "Extract the concrete damage claim from the conversation.",
            "Inspect every image independently.",
            "Return only allowed schema values.",
            "History adds risk context but must not override clear visual evidence.",
            "If all evidence is stock/screenshot/non-original, do not mark the claim supported.",
            "For multi-condition claims, supported requires all concrete claimed conditions to be visually supported.",
            "Use none only when the relevant part is visible and no damage is present; use unknown when not determinable.",
        ],
        "allowed_values": {
            "claim_status": sorted(CLAIM_STATUSES),
            "issue_type": sorted(ISSUE_TYPES),
            "object_part": sorted(OBJECT_PARTS[row["claim_object"]]),
            "risk_flags": sorted(RISK_FLAGS),
            "severity": sorted(SEVERITIES),
        },
    }
    response = client.responses.create(
        model=model,
        input=[
            {
                "role": "system",
                "content": (
                    "You are a meticulous insurance visual-evidence reviewer. "
                    "Return compact JSON only, with no markdown."
                ),
            },
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": json.dumps(prompt, ensure_ascii=False)},
                    *image_blocks,
                ],
            },
        ],
        text={
            "format": {
                "type": "json_schema",
                "name": "claim_review",
                "schema": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": OUTPUT_COLUMNS[4:],
                    "properties": {
                        "evidence_standard_met": {"type": "boolean"},
                        "evidence_standard_met_reason": {"type": "string"},
                        "risk_flags": {"type": "string"},
                        "issue_type": {"type": "string"},
                        "object_part": {"type": "string"},
                        "claim_status": {"type": "string"},
                        "claim_status_justification": {"type": "string"},
                        "supporting_image_ids": {"type": "string"},
                        "valid_image": {"type": "boolean"},
                        "severity": {"type": "string"},
                    },
                },
            }
        },
    )
    return json.loads(response.output_text)


def clean_bool(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return "true" if str(value).strip().lower() == "true" else "false"


def clean_prediction(
    row: dict[str, str], prediction: dict[str, Any], history: dict[str, str]
) -> dict[str, str]:
    result = {**{k: row[k] for k in ["user_id", "image_paths", "user_claim", "claim_object"]}}
    result["evidence_standard_met"] = clean_bool(
        prediction.get("evidence_standard_met", False)
    )
    result["valid_image"] = clean_bool(prediction.get("valid_image", False))
    result["evidence_standard_met_reason"] = str(
        prediction.get("evidence_standard_met_reason", "")
    )[:240] or "Evidence sufficiency reviewed against the submitted images."
    result["claim_status_justification"] = str(
        prediction.get("claim_status_justification", "")
    )[:280] or "Decision is based on submitted image evidence."

    issue = str(prediction.get("issue_type", "unknown")).strip()
    result["issue_type"] = issue if issue in ISSUE_TYPES else "unknown"
    part = str(prediction.get("object_part", "unknown")).strip()
    result["object_part"] = part if part in OBJECT_PARTS[row["claim_object"]] else "unknown"
    status = str(prediction.get("claim_status", "not_enough_information")).strip()
    result["claim_status"] = status if status in CLAIM_STATUSES else "not_enough_information"
    severity = str(prediction.get("severity", "unknown")).strip()
    result["severity"] = severity if severity in SEVERITIES else "unknown"

    submitted_ids = {image_id(p) for p in row["image_paths"].split(";")}
    ids = [
        x.strip()
        for x in str(prediction.get("supporting_image_ids", "none")).split(";")
        if x.strip() in submitted_ids
    ]
    result["supporting_image_ids"] = ";".join(ids) if ids else "none"

    flags = []
    raw_flags = str(prediction.get("risk_flags", "none"))
    for flag in re.split(r"[;,]", raw_flags):
        flag = flag.strip()
        if flag in RISK_FLAGS and flag != "none":
            flags.append(flag)
    for flag in str(history.get("history_flags", "none")).split(";"):
        flag = flag.strip()
        if flag in {"user_history_risk", "manual_review_required"}:
            flags.append(flag)
    result["risk_flags"] = ";".join(dict.fromkeys(flags)) if flags else "none"
    return result


def run(args: argparse.Namespace) -> None:
    dataset_root = Path(args.dataset_root).resolve()
    input_path = Path(args.input)
    if not input_path.is_absolute():
        input_path = dataset_root / input_path
    output_path = Path(args.output)
    if not output_path.is_absolute():
        output_path = Path.cwd() / output_path

    claims = read_csv(input_path)
    histories = load_lookup(dataset_root / "user_history.csv", "user_id")
    requirements = read_csv(dataset_root / "evidence_requirements.csv")
    use_openai = bool(os.environ.get("OPENAI_API_KEY")) and not args.no_vlm

    rows: list[dict[str, str]] = []
    for idx, row in enumerate(claims, start=1):
        history = histories.get(row["user_id"], {})
        if use_openai:
            for attempt in range(args.retries + 1):
                try:
                    pred = openai_review(row, history, requirements, dataset_root, args.model)
                    break
                except Exception as exc:
                    if attempt >= args.retries:
                        print(f"row {idx}: VLM failed, using fallback: {exc}", file=sys.stderr)
                        pred = base_prediction(row, history)
                    else:
                        time.sleep(2 * (attempt + 1))
        else:
            pred = base_prediction(row, history)
        rows.append(clean_prediction(row, pred, history))
    write_csv(output_path, rows)
    print(f"Wrote {len(rows)} rows to {output_path}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Multi-modal evidence claim reviewer")
    parser.add_argument("--dataset-root", default="dataset")
    parser.add_argument("--input", default="claims.csv")
    parser.add_argument("--output", default="output.csv")
    parser.add_argument("--model", default=os.environ.get("VLM_MODEL", "gpt-4.1-mini"))
    parser.add_argument("--retries", type=int, default=2)
    parser.add_argument("--no-vlm", action="store_true")
    return parser


if __name__ == "__main__":
    run(build_parser().parse_args())
