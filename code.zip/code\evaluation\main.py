from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from pathlib import Path


TARGET_COLUMNS = [
    "evidence_standard_met",
    "risk_flags",
    "issue_type",
    "object_part",
    "claim_status",
    "supporting_image_ids",
    "valid_image",
    "severity",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def score(expected: list[dict[str, str]], actual: list[dict[str, str]]) -> dict[str, float]:
    metrics: dict[str, float] = {}
    for col in TARGET_COLUMNS:
        correct = sum(
            str(e.get(col, "")).strip() == str(a.get(col, "")).strip()
            for e, a in zip(expected, actual)
        )
        metrics[col] = correct / max(1, len(expected))
    exact = sum(
        all(str(e.get(col, "")).strip() == str(a.get(col, "")).strip() for col in TARGET_COLUMNS)
        for e, a in zip(expected, actual)
    )
    metrics["row_exact_match"] = exact / max(1, len(expected))
    return metrics


def write_report(path: Path, metrics: dict[str, float], row_count: int, image_count: int) -> None:
    lines = [
        "# Evaluation Report",
        "",
        "## Sample Metrics",
        "",
        f"Rows evaluated: {row_count}",
        f"Images processed: {image_count}",
        "",
    ]
    for key, value in metrics.items():
        lines.append(f"- {key}: {value:.3f}")
    lines.extend(
        [
            "",
            "## Strategies Compared",
            "",
            "1. Deterministic text/history fallback: extracts likely issue and part from the conversation, adds user-history risk, and refuses to decide visual support without image review.",
            "2. Final VLM strategy: sends each claim, the relevant history, evidence requirements, and all images to a structured vision prompt, then validates values against the allowed schema.",
            "",
            "The final strategy is the VLM reviewer with deterministic schema sanitation. The fallback is included so the code remains runnable in environments without API credentials, but it is intentionally conservative because images are the primary source of truth.",
            "",
            "## Operational Analysis",
            "",
            "- Sample processing: 20 model calls and 29 images when the VLM path is enabled.",
            "- Test processing: 44 model calls and 82 images when the VLM path is enabled.",
            "- Approximate prompt tokens: 1.0k-1.4k text tokens per claim plus image tokens determined by the selected vision model and image detail.",
            "- Approximate output tokens: 120-220 per claim.",
            "- Pricing assumption: with a low-cost multimodal model such as `gpt-4.1-mini`, budget roughly a few cents for this dataset; exact cost depends on image tokenization and current provider pricing.",
            "- Latency: one request per row, typically 1-5 seconds per row depending on model load and image size; the provided runner is sequential for simplicity.",
            "- TPM/RPM: for larger runs, batch with a small worker pool, cache image-analysis outputs by file hash, and retry transient failures with exponential backoff.",
            "- Caching: image bytes are read once per claim in this implementation; a production variant should store per-image observations and combine them with claim-specific reasoning.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(args: argparse.Namespace) -> None:
    repo_root = Path(args.repo_root).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    sample_predictions = output_dir / "sample_predictions.csv"

    cmd = [
        sys.executable,
        str(repo_root / "code" / "main.py"),
        "--dataset-root",
        str(repo_root / "dataset"),
        "--input",
        "sample_claims.csv",
        "--output",
        str(sample_predictions),
    ]
    if args.no_vlm:
        cmd.append("--no-vlm")
    subprocess.run(cmd, check=True)

    expected = read_csv(repo_root / "dataset" / "sample_claims.csv")
    actual = read_csv(sample_predictions)
    metrics = score(expected, actual)
    image_count = sum(len(row["image_paths"].split(";")) for row in expected)
    write_report(output_dir / "evaluation_report.md", metrics, len(expected), image_count)
    print(f"Wrote {sample_predictions}")
    print(f"Wrote {output_dir / 'evaluation_report.md'}")


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Evaluate evidence reviewer on sample claims")
    p.add_argument("--repo-root", default=Path(__file__).resolve().parents[2])
    p.add_argument("--output-dir", default=Path(__file__).resolve().parent)
    p.add_argument("--no-vlm", action="store_true")
    return p


if __name__ == "__main__":
    run(parser().parse_args())
